#include <cuda_runtime.h>

#define BM 128
#define BN 128
#define BK 8

template <bool FAST>
__global__ void __launch_bounds__(256)
matmul_reg(const float* __restrict__ A, const float* __restrict__ B, float* __restrict__ C, int N) {
    __shared__ __align__(16) float As[BK][BM];
    __shared__ __align__(16) float Bs[BK][BN];

    const int tid = threadIdx.x;
    const int ty = tid >> 4;   // 0..15
    const int tx = tid & 15;   // 0..15
    const int rowBase = blockIdx.y * BM;
    const int colBase = blockIdx.x * BN;

    float acc[8][8];
#pragma unroll
    for (int i = 0; i < 8; ++i)
#pragma unroll
        for (int j = 0; j < 8; ++j) acc[i][j] = 0.f;

    const int numTiles = (N + BK - 1) / BK;

    for (int t = 0; t < numTiles; ++t) {
        const int k0 = t * BK;
        if (FAST) {
            int r = tid >> 1, kc = (tid & 1) * 4;
            float4 a = *reinterpret_cast<const float4*>(&A[(size_t)(rowBase + r) * N + k0 + kc]);
            As[kc + 0][r] = a.x; As[kc + 1][r] = a.y;
            As[kc + 2][r] = a.z; As[kc + 3][r] = a.w;
            int br = tid >> 5, bc = (tid & 31) * 4;
            float4 b = *reinterpret_cast<const float4*>(&B[(size_t)(k0 + br) * N + colBase + bc]);
            *reinterpret_cast<float4*>(&Bs[br][bc]) = b;
        } else {
#pragma unroll
            for (int i = 0; i < 4; ++i) {
                int e = tid + i * 256;
                int r = e >> 3, kk = e & 7;
                int gr = rowBase + r, gk = k0 + kk;
                As[kk][r] = (gr < N && gk < N) ? A[(size_t)gr * N + gk] : 0.f;
                int bk = e >> 7, c = e & 127;
                int gbk = k0 + bk, gc = colBase + c;
                Bs[bk][c] = (gbk < N && gc < N) ? B[(size_t)gbk * N + gc] : 0.f;
            }
        }
        __syncthreads();

#pragma unroll
        for (int k = 0; k < BK; ++k) {
            float4 a0 = *reinterpret_cast<const float4*>(&As[k][ty * 4]);
            float4 a1 = *reinterpret_cast<const float4*>(&As[k][64 + ty * 4]);
            float4 b0 = *reinterpret_cast<const float4*>(&Bs[k][tx * 4]);
            float4 b1 = *reinterpret_cast<const float4*>(&Bs[k][64 + tx * 4]);
            float a[8] = {a0.x, a0.y, a0.z, a0.w, a1.x, a1.y, a1.z, a1.w};
            float b[8] = {b0.x, b0.y, b0.z, b0.w, b1.x, b1.y, b1.z, b1.w};
#pragma unroll
            for (int i = 0; i < 8; ++i)
#pragma unroll
                for (int j = 0; j < 8; ++j) acc[i][j] = fmaf(a[i], b[j], acc[i][j]);
        }
        __syncthreads();
    }

#pragma unroll
    for (int i = 0; i < 8; ++i) {
        int r = rowBase + (i < 4 ? ty * 4 + i : 64 + ty * 4 + (i - 4));
#pragma unroll
        for (int h = 0; h < 2; ++h) {
            int c = colBase + (h == 0 ? tx * 4 : 64 + tx * 4);
            if (FAST) {
                *reinterpret_cast<float4*>(&C[(size_t)r * N + c]) =
                    make_float4(acc[i][h * 4 + 0], acc[i][h * 4 + 1], acc[i][h * 4 + 2], acc[i][h * 4 + 3]);
            } else {
                if (r < N) {
#pragma unroll
                    for (int j = 0; j < 4; ++j)
                        if (c + j < N) C[(size_t)r * N + c + j] = acc[i][h * 4 + j];
                }
            }
        }
    }
}

void launch(const float* A, const float* B, float* C, int N) {
    dim3 block(256);
    dim3 grid((N + BN - 1) / BN, (N + BM - 1) / BM);
    if (N % 128 == 0)
        matmul_reg<true><<<grid, block>>>(A, B, C, N);
    else
        matmul_reg<false><<<grid, block>>>(A, B, C, N);
}
