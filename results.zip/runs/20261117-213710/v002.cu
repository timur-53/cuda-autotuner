#include <cuda_runtime.h>

#define BM 128
#define BN 128
#define BK 8

template <bool VEC>
__global__ __launch_bounds__(256) void sgemm_kernel(const float* __restrict__ A,
                                                    const float* __restrict__ B,
                                                    float* __restrict__ C, int N) {
    __shared__ __align__(16) float As[2][BK][BM + 4];
    __shared__ __align__(16) float Bs[2][BK][BN];

    const int tid = threadIdx.x;
    const int tx = tid & 15;
    const int ty = tid >> 4;
    const int bm = blockIdx.y * BM;
    const int bn = blockIdx.x * BN;

    // load mapping
    const int a_r = tid >> 1;
    const int a_k = (tid & 1) * 4;
    const int b_k = tid >> 5;
    const int b_c = (tid & 31) * 4;

    float acc[8][8];
#pragma unroll
    for (int i = 0; i < 8; ++i)
#pragma unroll
        for (int j = 0; j < 8; ++j) acc[i][j] = 0.f;

    const int numTiles = (N + BK - 1) / BK;

    float4 ra, rb;

    auto gload = [&](int k0) {
        int gr = bm + a_r, gk = k0 + a_k;
        int bk = k0 + b_k, gc = bn + b_c;
        if (VEC) {
            ra = (gr < N && gk < N) ? *reinterpret_cast<const float4*>(&A[(size_t)gr * N + gk])
                                    : make_float4(0.f, 0.f, 0.f, 0.f);
            rb = (bk < N && gc < N) ? *reinterpret_cast<const float4*>(&B[(size_t)bk * N + gc])
                                    : make_float4(0.f, 0.f, 0.f, 0.f);
        } else {
            float t[4];
#pragma unroll
            for (int i = 0; i < 4; ++i)
                t[i] = (gr < N && gk + i < N) ? A[(size_t)gr * N + gk + i] : 0.f;
            ra = make_float4(t[0], t[1], t[2], t[3]);
#pragma unroll
            for (int i = 0; i < 4; ++i)
                t[i] = (bk < N && gc + i < N) ? B[(size_t)bk * N + gc + i] : 0.f;
            rb = make_float4(t[0], t[1], t[2], t[3]);
        }
    };
    auto sstore = [&](int buf) {
        As[buf][a_k + 0][a_r] = ra.x;
        As[buf][a_k + 1][a_r] = ra.y;
        As[buf][a_k + 2][a_r] = ra.z;
        As[buf][a_k + 3][a_r] = ra.w;
        *reinterpret_cast<float4*>(&Bs[buf][b_k][b_c]) = rb;
    };

    gload(0);
    sstore(0);
    __syncthreads();

    for (int t = 0; t < numTiles; ++t) {
        const int cur = t & 1;
        if (t + 1 < numTiles) gload((t + 1) * BK);

#pragma unroll
        for (int k = 0; k < BK; ++k) {
            float a[8], b[8];
            float4 a0 = *reinterpret_cast<const float4*>(&As[cur][k][ty * 4]);
            float4 a1 = *reinterpret_cast<const float4*>(&As[cur][k][ty * 4 + 64]);
            float4 b0 = *reinterpret_cast<const float4*>(&Bs[cur][k][tx * 4]);
            float4 b1 = *reinterpret_cast<const float4*>(&Bs[cur][k][tx * 4 + 64]);
            a[0] = a0.x; a[1] = a0.y; a[2] = a0.z; a[3] = a0.w;
            a[4] = a1.x; a[5] = a1.y; a[6] = a1.z; a[7] = a1.w;
            b[0] = b0.x; b[1] = b0.y; b[2] = b0.z; b[3] = b0.w;
            b[4] = b1.x; b[5] = b1.y; b[6] = b1.z; b[7] = b1.w;
#pragma unroll
            for (int i = 0; i < 8; ++i)
#pragma unroll
                for (int j = 0; j < 8; ++j) acc[i][j] = fmaf(a[i], b[j], acc[i][j]);
        }

        if (t + 1 < numTiles) sstore(cur ^ 1);
        __syncthreads();
    }

#pragma unroll
    for (int i = 0; i < 8; ++i) {
        int row = bm + ty * 4 + (i & 3) + (i >> 2) * 64;
        if (row >= N) continue;
#pragma unroll
        for (int h = 0; h < 2; ++h) {
            int col = bn + tx * 4 + h * 64;
            if (VEC) {
                if (col < N)
                    *reinterpret_cast<float4*>(&C[(size_t)row * N + col]) =
                        make_float4(acc[i][h * 4 + 0], acc[i][h * 4 + 1],
                                    acc[i][h * 4 + 2], acc[i][h * 4 + 3]);
            } else {
#pragma unroll
                for (int j = 0; j < 4; ++j)
                    if (col + j < N) C[(size_t)row * N + col + j] = acc[i][h * 4 + j];
            }
        }
    }
}

void launch(const float* A, const float* B, float* C, int N) {
    dim3 block(256);
    dim3 grid((N + BN - 1) / BN, (N + BM - 1) / BM);
    bool aligned = (N % 4 == 0) &&
                   (((size_t)A | (size_t)B | (size_t)C) & 15) == 0;
    if (aligned)
        sgemm_kernel<true><<<grid, block>>>(A, B, C, N);
    else
        sgemm_kernel<false><<<grid, block>>>(A, B, C, N);
}
