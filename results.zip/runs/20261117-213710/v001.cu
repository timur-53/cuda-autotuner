#include <cuda_runtime.h>

#define BM 128
#define BN 128
#define BK 8

__global__ __launch_bounds__(256) void sgemm_kernel(const float* __restrict__ A,
                                                    const float* __restrict__ B,
                                                    float* __restrict__ C, int N) {
    __shared__ __align__(16) float As[BK][BM + 4];
    __shared__ __align__(16) float Bs[BK][BN];

    const int tid = threadIdx.x;
    const int tx = tid & 15;
    const int ty = tid >> 4;
    const int bm = blockIdx.y * BM;
    const int bn = blockIdx.x * BN;

    float acc[8][8];
#pragma unroll
    for (int i = 0; i < 8; ++i)
#pragma unroll
        for (int j = 0; j < 8; ++j) acc[i][j] = 0.f;

    for (int k0 = 0; k0 < N; k0 += BK) {
#pragma unroll
        for (int i = 0; i < 4; ++i) {
            int idx = tid + i * 256;
            int ar = idx >> 3, ak = idx & 7;
            int gr = bm + ar, gk = k0 + ak;
            As[ak][ar] = (gr < N && gk < N) ? A[(size_t)gr * N + gk] : 0.f;
        }
#pragma unroll
        for (int i = 0; i < 4; ++i) {
            int idx = tid + i * 256;
            int bk = idx >> 7, bc = idx & 127;
            int gk = k0 + bk, gc = bn + bc;
            Bs[bk][bc] = (gk < N && gc < N) ? B[(size_t)gk * N + gc] : 0.f;
        }
        __syncthreads();

#pragma unroll
        for (int k = 0; k < BK; ++k) {
            float a[8], b[8];
            float4 a0 = *reinterpret_cast<const float4*>(&As[k][ty * 4]);
            float4 a1 = *reinterpret_cast<const float4*>(&As[k][ty * 4 + 64]);
            float4 b0 = *reinterpret_cast<const float4*>(&Bs[k][tx * 4]);
            float4 b1 = *reinterpret_cast<const float4*>(&Bs[k][tx * 4 + 64]);
            a[0] = a0.x; a[1] = a0.y; a[2] = a0.z; a[3] = a0.w;
            a[4] = a1.x; a[5] = a1.y; a[6] = a1.z; a[7] = a1.w;
            b[0] = b0.x; b[1] = b0.y; b[2] = b0.z; b[3] = b0.w;
            b[4] = b1.x; b[5] = b1.y; b[6] = b1.z; b[7] = b1.w;
#pragma unroll
            for (int i = 0; i < 8; ++i)
#pragma unroll
                for (int j = 0; j < 8; ++j) acc[i][j] = fmaf(a[i], b[j], acc[i][j]);
        }
        __syncthreads();
    }

#pragma unroll
    for (int i = 0; i < 8; ++i) {
        int row = bm + ty * 4 + (i & 3) + (i >> 2) * 64;
        if (row >= N) continue;
#pragma unroll
        for (int j = 0; j < 8; ++j) {
            int col = bn + tx * 4 + (j & 3) + (j >> 2) * 64;
            if (col < N) C[(size_t)row * N + col] = acc[i][j];
        }
    }
}

void launch(const float* A, const float* B, float* C, int N) {
    dim3 block(256);
    dim3 grid((N + BN - 1) / BN, (N + BM - 1) / BM);
    sgemm_kernel<<<grid, block>>>(A, B, C, N);
}
