#include <cuda_runtime.h>

#define BM 128
#define BN 128
#define BK 16

template <bool VEC>
__global__ __launch_bounds__(256) void sgemm_kernel(const float* __restrict__ A,
                                                    const float* __restrict__ B,
                                                    float* __restrict__ C, int N) {
    __shared__ __align__(16) float As[BK][BM + 4];
    __shared__ __align__(16) float Bs[BK][BN];

    const int tid = threadIdx.x;
    const int tx = tid & 15;
    const int ty = tid >> 4;
    const int bm = blockIdx.y * BM;
    const int bn = blockIdx.x * BN;

    float acc[8][8];
#pragma unroll
    for (int i = 0; i < 8; ++i)
#pragma unroll
        for (int j = 0; j < 8; ++j) acc[i][j] = 0.f;

    for (int k0 = 0; k0 < N; k0 += BK) {
        // Load A tile (128 x 16), stored transposed
#pragma unroll
        for (int i = 0; i < 2; ++i) {
            int idx = tid + i * 256;
            int ar = idx >> 2;
            int kq = (idx & 3) * 4;
            int gr = bm + ar, gk = k0 + kq;
            float4 v = make_float4(0.f, 0.f, 0.f, 0.f);
            if (VEC) {
                if (gr < N && gk < N)
                    v = *reinterpret_cast<const float4*>(&A[(size_t)gr * N + gk]);
            } else {
                if (gr < N) {
                    const float* p = &A[(size_t)gr * N];
                    if (gk + 0 < N) v.x = p[gk + 0];
                    if (gk + 1 < N) v.y = p[gk + 1];
                    if (gk + 2 < N) v.z = p[gk + 2];
                    if (gk + 3 < N) v.w = p[gk + 3];
                }
            }
            As[kq + 0][ar] = v.x;
            As[kq + 1][ar] = v.y;
            As[kq + 2][ar] = v.z;
            As[kq + 3][ar] = v.w;
        }
        // Load B tile (16 x 128)
#pragma unroll
        for (int i = 0; i < 2; ++i) {
            int idx = tid + i * 256;
            int bk = idx >> 5;
            int bc = (idx & 31) * 4;
            int gk = k0 + bk, gc = bn + bc;
            float4 v = make_float4(0.f, 0.f, 0.f, 0.f);
            if (VEC) {
                if (gk < N && gc < N)
                    v = *reinterpret_cast<const float4*>(&B[(size_t)gk * N + gc]);
            } else {
                if (gk < N) {
                    const float* p = &B[(size_t)gk * N];
                    if (gc + 0 < N) v.x = p[gc + 0];
                    if (gc + 1 < N) v.y = p[gc + 1];
                    if (gc + 2 < N) v.z = p[gc + 2];
                    if (gc + 3 < N) v.w = p[gc + 3];
                }
            }
            *reinterpret_cast<float4*>(&Bs[bk][bc]) = v;
        }
        __syncthreads();

#pragma unroll
        for (int k = 0; k < BK; ++k) {
            float a[8], b[8];
            float4 a0 = *reinterpret_cast<const float4*>(&As[k][ty * 4]);
            float4 a1 = *reinterpret_cast<const float4*>(&As[k][ty * 4 + 64]);
            float4 b0 = *reinterpret_cast<const float4*>(&Bs[k][tx * 4]);
            float4 b1 = *reinterpret_cast<const float4*>(&Bs[k][tx * 4 + 64]);
            a[0] = a0.x; a[1] = a0.y; a[2] = a0.z; a[3] = a0.w;
            a[4] = a1.x; a[5] = a1.y; a[6] = a1.z; a[7] = a1.w;
            b[0] = b0.x; b[1] = b0.y; b[2] = b0.z; b[3] = b0.w;
            b[4] = b1.x; b[5] = b1.y; b[6] = b1.z; b[7] = b1.w;
#pragma unroll
            for (int i = 0; i < 8; ++i)
#pragma unroll
                for (int j = 0; j < 8; ++j) acc[i][j] = fmaf(a[i], b[j], acc[i][j]);
        }
        __syncthreads();
    }

#pragma unroll
    for (int i = 0; i < 8; ++i) {
        int row = bm + ty * 4 + (i & 3) + (i >> 2) * 64;
        if (row >= N) continue;
#pragma unroll
        for (int jh = 0; jh < 2; ++jh) {
            int col = bn + tx * 4 + jh * 64;
            if (VEC) {
                if (col < N) {
                    float4 v = make_float4(acc[i][jh * 4 + 0], acc[i][jh * 4 + 1],
                                           acc[i][jh * 4 + 2], acc[i][jh * 4 + 3]);
                    *reinterpret_cast<float4*>(&C[(size_t)row * N + col]) = v;
                }
            } else {
#pragma unroll
                for (int j = 0; j < 4; ++j)
                    if (col + j < N) C[(size_t)row * N + col + j] = acc[i][jh * 4 + j];
            }
        }
    }
}

void launch(const float* A, const float* B, float* C, int N) {
    dim3 block(256);
    dim3 grid((N + BN - 1) / BN, (N + BM - 1) / BM);
    if ((N & 3) == 0)
        sgemm_kernel<true><<<grid, block>>>(A, B, C, N);
    else
        sgemm_kernel<false><<<grid, block>>>(A, B, C, N);
}
